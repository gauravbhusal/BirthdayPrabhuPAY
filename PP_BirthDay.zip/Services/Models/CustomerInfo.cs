﻿namespace Services.Models
{
    public class CustomerInfo
    {
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
        public string Message { get; set; }
    }
}
