﻿namespace Services.Models
{
    public class LogInfo
    {
        public string Message { get; set; }
        public string MobileNumber { get; set; }
        public string Status { get; set; }
    }
}
